# notion_widgets
A set of HTML widgets that could be embedded into [Notion.so](https://www.notion.so/) pages.
[learn more](https://blog.shorouk.dev/notion-widgets-gallery/)
